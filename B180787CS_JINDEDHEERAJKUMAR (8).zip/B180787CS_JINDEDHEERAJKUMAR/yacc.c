%{
#include <stdio.h>
#include "y.tab.h"
extern yylval;
%}

%%
[ \t];
printf( "numbers is %d\n",yyval);
{
	return digit;
}


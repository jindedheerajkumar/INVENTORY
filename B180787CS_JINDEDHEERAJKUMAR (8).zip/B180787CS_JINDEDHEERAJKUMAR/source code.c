#include <stdio.h>
#include <stdlib.h>

 // return "true" if the character is a delimiter
 bool is delimiter(char ch)
 {
 	if (ch == '' || ch == '+' || ch == '-' ||
	 ch =='*' || ch == '/' || ch == ',' || ch == ';'
	 || ch == '=' || ch == '<' || ch== '>' 
	 || ch == '(' || ch == ')' || ch == '(' || ch == ';')
	 
	 return (true);
	 return (false);
 }
int main ()

{
	// maximum length of my string is 100
	char str [100];
	printf ("type the line of code: \n");
	scanf ("%[^\n]", &str);
	
	return (0);
}

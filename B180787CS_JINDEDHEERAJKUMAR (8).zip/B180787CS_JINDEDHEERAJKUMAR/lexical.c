#include <stdio.h>
#include <stdlib.h>

$lex x.l
$ cc lex.yy.c
$ .\a.out
main ()
{
	yylex();
}

int yywrap()

{
	return1;
}
